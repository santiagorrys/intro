package com.recicladoria.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.recicladoria.app.comms.BinType
import com.recicladoria.app.comms.Esp32WebSocketClient
import com.recicladoria.app.ui.MainScreen

class MainActivity : ComponentActivity() {

    private lateinit var wsClient: Esp32WebSocketClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        wsClient = Esp32WebSocketClient()

        setContent {
            MaterialTheme {
                val connectionState by wsClient.connectionState.collectAsState()
                val logs by wsClient.logs.collectAsState()

                MainScreen(
                    connectionState = connectionState,
                    logs = logs,
                    onOpenWhite = { wsClient.sendOpen(BinType.WHITE) },
                    onOpenGreen = { wsClient.sendOpen(BinType.GREEN) },
                    onPing = { wsClient.sendPing() },
                    onClearLogs = { wsClient.clearLogs() }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        wsClient.connect()
    }

    override fun onStop() {
        super.onStop()
        wsClient.disconnect()
    }

    override fun onDestroy() {
        wsClient.release()
        super.onDestroy()
    }
}