package com.recicladoria.app.comms

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class BinType(val wireValue: String, val displayName: String) {
    WHITE("WHITE", "Caneca blanca"),
    GREEN("GREEN", "Caneca verde")
}

enum class ConnectionState(val label: String) {
    DISCONNECTED("Desconectado"),
    CONNECTING("Conectando..."),
    CONNECTED("Conectado")
}

enum class LogDirection(val tag: String) {
    SENT("TX"),
    RECEIVED("RX"),
    SYSTEM("SYS")
}

data class LogEntry(
    val timestamp: String,
    val direction: LogDirection,
    val message: String
) {
    companion object {
        fun now(direction: LogDirection, message: String): LogEntry {
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            return LogEntry(
                timestamp = sdf.format(Date()),
                direction = direction,
                message = message
            )
        }
    }
}

object Esp32Protocol {

    fun buildOpenCommand(bin: BinType, id: Int): String {
        return JSONObject().apply {
            put("cmd", "OPEN")
            put("bin", bin.wireValue)
            put("id", id)
        }.toString()
    }

    fun buildPingCommand(id: Int): String {
        return JSONObject().apply {
            put("cmd", "PING")
            put("id", id)
        }.toString()
    }
}