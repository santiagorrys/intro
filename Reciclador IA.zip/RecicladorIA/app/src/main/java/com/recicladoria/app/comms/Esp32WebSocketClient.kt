package com.recicladoria.app.comms

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class Esp32WebSocketClient(
    private val serverUrl: String = DEFAULT_WS_URL
) {
    companion object {
        const val DEFAULT_WS_URL = "ws://192.168.4.1/ws"
        private const val RECONNECT_DELAY_MS = 3000L
        private const val MAX_LOG_ENTRIES = 100

        // Contador incremental único durante la vida del proceso (1, 2, 3...)
        private val commandIdGenerator = AtomicInteger(0)
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Obligatorio para WebSockets persistentes
        .pingInterval(15, TimeUnit.SECONDS)    // Detecta caídas silenciosas de red
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var webSocket: WebSocket? = null

    @Volatile
    private var shouldReconnect = false

    private var reconnectJob: Job? = null

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    fun connect() {
        shouldReconnect = true
        if (_connectionState.value == ConnectionState.CONNECTED ||
            _connectionState.value == ConnectionState.CONNECTING
        ) {
            return
        }
        openSocket()
    }

    fun disconnect() {
        shouldReconnect = false
        reconnectJob?.cancel()
        reconnectJob = null

        val socket = webSocket
        webSocket = null
        socket?.close(1000, "Desconexión solicitada por la app")
        _connectionState.value = ConnectionState.DISCONNECTED
    }

    fun release() {
        disconnect()
        scope.cancel()
        okHttpClient.dispatcher.executorService.shutdown()
    }

    fun sendOpen(bin: BinType) {
        val id = commandIdGenerator.incrementAndGet()
        val payload = Esp32Protocol.buildOpenCommand(bin, id)
        sendRawJson(payload)
    }

    fun sendPing() {
        val id = commandIdGenerator.incrementAndGet()
        val payload = Esp32Protocol.buildPingCommand(id)
        sendRawJson(payload)
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    private fun sendRawJson(json: String) {
        val socket = webSocket
        if (socket == null || _connectionState.value != ConnectionState.CONNECTED) {
            appendLog(LogDirection.SYSTEM, "No enviado (sin conexión): $json")
            return
        }

        val queued = socket.send(json)
        if (queued) {
            appendLog(LogDirection.SENT, json)
        } else {
            appendLog(LogDirection.SYSTEM, "Error al encolar mensaje: $json")
        }
    }

    private fun openSocket() {
        reconnectJob?.cancel()
        _connectionState.value = ConnectionState.CONNECTING
        appendLog(LogDirection.SYSTEM, "Conectando a $serverUrl...")

        val request = Request.Builder()
            .url(serverUrl)
            .build()

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {

            override fun onOpen(ws: WebSocket, response: Response) {
                if (ws !== webSocket) return
                _connectionState.value = ConnectionState.CONNECTED
                appendLog(LogDirection.SYSTEM, "Conectado al ESP32.")
            }

            override fun onMessage(ws: WebSocket, text: String) {
                if (ws !== webSocket) return
                appendLog(LogDirection.RECEIVED, text)
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                if (ws !== webSocket) return
                ws.close(1000, null)
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                if (ws !== webSocket) return
                webSocket = null
                _connectionState.value = ConnectionState.DISCONNECTED
                appendLog(LogDirection.SYSTEM, "Conexión cerrada ($code).")
                scheduleReconnect()
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                if (ws !== webSocket) return
                webSocket = null
                _connectionState.value = ConnectionState.DISCONNECTED
                val detalle = t.message ?: "Error de red"
                appendLog(LogDirection.SYSTEM, "Fallo de conexión: $detalle")
                scheduleReconnect()
            }
        })
    }

    private fun scheduleReconnect() {
        if (!shouldReconnect) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            appendLog(LogDirection.SYSTEM, "Reintentando en ${RECONNECT_DELAY_MS / 1000} s...")
            delay(RECONNECT_DELAY_MS)
            if (shouldReconnect && _connectionState.value == ConnectionState.DISCONNECTED) {
                openSocket()
            }
        }
    }

    private fun appendLog(direction: LogDirection, message: String) {
        _logs.update { current ->
            (current + LogEntry.now(direction, message)).takeLast(MAX_LOG_ENTRIES)
        }
    }
}